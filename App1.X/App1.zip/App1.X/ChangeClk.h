/* 
 * File:   
 * Author: Shahdad
 * Comments:
 * Revision history: 
 */
 
#ifndef CHANGECLK_H
#define	CHANGECLK_H

#include <xc.h>  



void NewClk(unsigned int clkval);


#endif	dif	